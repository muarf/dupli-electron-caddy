<div class="navbar navbar-default navbar-fixed-bottom">
    <div class="container" style="display: flex; align-items: center; justify-content: space-between; height: 100%;">
        <button type="button" class="btn btn-default btn-sm" onclick="history.back()" style="display: flex; align-items: center; margin-top: 6px;">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span> <?php _e('footer.previous'); ?>
        </button>
        <p class="navbar-text text-center" style="margin: 0; flex: 1;"><?php _e('footer.coded_with_love'); ?> <a href="https://github.com/muarf/dupli-electron-caddy/"> <?php _e('footer.github'); ?> </a></p>
        <div style="width: 80px;"></div> <!-- Espace pour équilibrer -->
    </div>
</div>