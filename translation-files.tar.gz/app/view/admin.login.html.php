<style>
    .login-container {
        max-width: 400px;
        margin: 50px auto;
        background: white;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 0 20px rgba(0,0,0,0.1);
    }
    .login-header {
        text-align: center;
        margin-bottom: 30px;
    }
    .login-header h2 {
        color: #333;
        margin-bottom: 10px;
    }
    .form-group {
        margin-bottom: 20px;
    }
    .btn-login {
        width: 100%;
        background-color: #007bff;
        border-color: #007bff;
        padding: 12px;
        font-size: 16px;
    }
    .btn-login:hover {
        background-color: #0056b3;
        border-color: #0056b3;
    }
    .alert-danger {
        animation: shake 0.5s;
    }
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
        20%, 40%, 60%, 80% { transform: translateX(5px); }
    }
</style>

<div class="login-container">
    <div class="login-header">
        <h2>🔐 <?php _e('admin_login.title'); ?></h2>
        <p class="text-muted"><?php _e('admin_login.login_required'); ?></p>
    </div>
    
    <?php if (!empty($login_error)): ?>
        <div class="alert alert-danger" role="alert">
            <i class="fa fa-exclamation-triangle"></i> <?= htmlspecialchars($login_error) ?>
        </div>
    <?php endif; ?>
    
    <form method="POST" action="?admin">
        <div class="form-group">
            <label for="password"><?php _e('admin_login.password'); ?> :</label>
            <input type="password" class="form-control" id="password" name="password" required autofocus>
        </div>
        
        <button type="submit" class="btn btn-primary btn-login">
            <i class="fa fa-sign-in"></i> <?php _e('admin_login.login'); ?>
        </button>
    </form>
    
    <div class="text-center mt-3">
        <a href="?accueil" class="text-muted">
            <i class="fa fa-arrow-left"></i> <?php _e('admin_login.back_to_home'); ?>
        </a>
    </div>
</div>